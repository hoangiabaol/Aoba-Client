/*
 * Aoba Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package net.aoba.gui.navigation.windows;

import net.aoba.gui.navigation.Window;

public class FriendsWindow extends Window {

	// private HashMap<ServerPlayerEntity, CheckboxComponent> checkboxes = new
	// HashMap<ServerPlayerEntity, CheckboxComponent>();
	// private boolean isDirty = false;

	public FriendsWindow(String title, int x, int y) {
		super(title, x, y);
	}
}
