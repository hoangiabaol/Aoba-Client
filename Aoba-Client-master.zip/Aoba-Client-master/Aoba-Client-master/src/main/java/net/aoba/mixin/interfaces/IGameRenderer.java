package net.aoba.mixin.interfaces;

import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.client.render.GameRenderer;

@Mixin(GameRenderer.class)
public interface IGameRenderer {

}
